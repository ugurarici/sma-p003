<?php

$name = "Uğur";
$surname = "Arıcı";
echo $_GET['id'];

function hello($name, $surname = "Yıldız")
{
    return "Hello $name " . $surname . "id " . $_GET['id'];
}

$soyadi = $_GET['soyadi'];
echo hello("Mahmut", $soyadi);
echo "<hr>";
echo $name;
echo "<hr>";
echo $surname;
